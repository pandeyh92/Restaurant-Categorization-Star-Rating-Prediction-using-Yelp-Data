import re
from nltk.corpus import stopwords
import json
import sys
from sklearn.metrics import mean_squared_error

reload(sys)
sys.setdefaultencoding('utf8')

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
import scipy.stats as stats
import numpy as np
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from collections import Counter
from sklearn import cross_validation
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
import pandas as pd

import pylab as pl
def showdistribution(data):
    h = sorted(data)  # sorted

    fit = stats.norm.pdf(h, np.mean(h), np.std(h))  # this is a fitting indeed

    pl.plot(h, fit, '-o')

    pl.hist(h, normed=True)  # use this to draw histogram of your data

    pl.show()
def load_file():


    df = pd.read_csv('mexicanFinal.csv')
    #df = pd.read_csv('americanFinal.csv')
    sent_label=[]
    for i in xrange(df['text'].__len__()):
        if df['stars'][i]<3:
            sent_label.append(-1)
        elif df['stars'][i]>3:
            sent_label.append(1)
        else:
            sent_label.append(0)

    df['sentiment'] = sent_label
    showdistribution(df['stars'])
    showdistribution(df['sentiment'])
    #df.to_csv("newamerican.csv")

    #df1=df[:500]
    df1=df
    review_text = df1["text"]
    stars = df1["sentiment"]
    return review_text, stars

def CalculateTF(data,target):
    count_vectorizerSVM = CountVectorizer(binary='false',ngram_range=(1,2))
    dataSVM = count_vectorizerSVM.fit_transform(data.values.astype('U'))
    tfidf_dataSVM = TfidfTransformer(use_idf=True,smooth_idf=True).fit_transform(dataSVM)
    print "Calculating term frequency."
    return tfidf_dataSVM

def learn_model(dataSVM, target):
    print "applying cross validation with 80% train and 20% test data"
    data_train, data_test, target_train, target_test = cross_validation.train_test_split(dataSVM, target, test_size=0.2,
                                                                                         random_state=37)

    print "Applying SVM classification now"
    svm = SVC(probability=False,random_state=33,kernel='linear',shrinking=True)
    classifier = svm.fit(data_train, target_train)
    predicted = classifier.predict(data_test)
    print "Predictions completed!"
    print classification_report(target_test, predicted)
    print "The accuracy score is {:.2%}".format(accuracy_score(target_test, predicted))


def main():
    print ("Loading the reviews data..")
    data,target = load_file()
    print "Data Loaded.Now Preprocessing ..."
    tf_idfSVM = CalculateTF(data, target)
    learn_model(tf_idfSVM, target)

main()