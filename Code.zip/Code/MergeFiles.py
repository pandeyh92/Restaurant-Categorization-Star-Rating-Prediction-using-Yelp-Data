import pandas as pd

df1 = pd.read_csv("yelp_academic_dataset_review.csv")
df2 = pd.read_csv("yelp_academic_dataset_business_relevant1.csv")

merged = pd.merge(left=df2, right=df1, how='inner', left_on="business_id", right_on='business_id')

merged.to_csv("merged_data.csv",index=False)