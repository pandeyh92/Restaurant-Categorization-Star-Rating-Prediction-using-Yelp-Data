from pandas.io.parsers import read_csv

data = read_csv('mexican1.csv')
filtered_data = data.dropna(axis='rows', how='all')
filtered_data.to_csv('empty-columns-removed.csv')