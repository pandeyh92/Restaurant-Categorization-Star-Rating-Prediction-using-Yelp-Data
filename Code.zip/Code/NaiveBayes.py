import re
from nltk.corpus import stopwords
import json
import sys
from sklearn.metrics import mean_squared_error

reload(sys)
sys.setdefaultencoding('utf8')

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer

from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from collections import Counter
from sklearn import cross_validation
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
import pandas as pd

def load_file():
    #df = pd.read_csv('americanFinal.csv')
    df = pd.read_csv('mexicanFinal.csv')
    sent_label = []
    for i in xrange(df['text'].__len__()):
        if df['stars'][i] < 3:
            sent_label.append(-1)
        elif df['stars'][i] > 3:
            sent_label.append(1)
        else:
            sent_label.append(0)

    df['sentiment'] = sent_label
    df1 = df
    #df1=df[:500]
    review_text = df1["text"]
    stars = df1["sentiment"]
    return review_text, stars


def CalculateTF(data,target):

    count_vectorizerNB = CountVectorizer(binary='false',ngram_range=(0,1))
    dataNB = count_vectorizerNB.fit_transform(data.values.astype('U'))
    tfidf_dataNB = TfidfTransformer(use_idf=True,smooth_idf=True).fit_transform(dataNB)
    print "Calculating term frequency."
    return tfidf_dataNB

def learn_model(dataNB, target):
    print "applying cross validation with 80% train and 20% test data"
    data_train, data_test, target_train, target_test = cross_validation.train_test_split(dataNB, target, test_size=0.2,
                                                                                         random_state=37)


    print "Applying Naive Bayes Model"
    classifier = MultinomialNB().fit(data_train, target_train)
    predictedNB = classifier.predict(data_test)
    print classification_report(target_test, predictedNB)
    print "The accuracy score is {:.2%}".format(accuracy_score(target_test, predictedNB))


def main():
    print ("Loading the reviews data..")
    data,target = load_file()
    print "Data loaded.Now Preprocessing ..."
    tf_idfNB = CalculateTF(data, target)
    learn_model(tf_idfNB, target)

main()